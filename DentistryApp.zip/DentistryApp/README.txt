This app will save its data to these files:
Dentists.txt
Procedures.txt
Patients.txt
overwriting them if needed without asking for permission.
It also uses the icon.png provided with it.